import java.util.Scanner;

public class Algo1_광주_3반_정희수 {

	static class group{
		String str;
		int time;
		public group(String str,int time) {
			// TODO Auto-generated constructor stub
			this.str=str;
			this.time=time;
		}
	}
	
	static int T;
	static Scanner sc=new Scanner(System.in);
	static group[] tele=new group[9];

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		tele[0]=new group("ABC",3);
		tele[1]=new group("DEF",4);
		tele[2]=new group("GHI",5);
		tele[3]=new group("JKL",6);
		tele[4]=new group("MNO",7);
		tele[5]=new group("PQRS",8);
		tele[6]=new group("TUV",9);
		tele[7]=new group("WXYZ",10);
		
		T=sc.nextInt();
		for (int tc = 1; tc <=T; tc++) {
			String input=sc.next();
			
			int resul=0;
			for (int i = 0; i <input.length(); i++) {
				String c=Character.toString(input.charAt(i));
				for (int j = 0; j <tele.length; j++) {
					if(tele[j].str.contains(c)) {
						resul+=tele[j].time;
						break;
					}
				}
			}
			System.out.println("#"+tc+" "+resul);
		}//tc
	}
	
}
