import java.util.Scanner;

public class Algo2_광주_3반_정희수 {

	static int T;
	static int N;
	static char[][] map;
	
	static Scanner sc=new Scanner(System.in);
	static int[] Ax= {0};
	static int[] Ay= {1};
	static int[] Bx= {-1,1};
	static int[] By= {0,0};
	static int[] Cx= {-1,-1,1,1};
	static int[] Cy= {-1,1,1,-1};
	
	static int go() {
		int resul=0;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if(map[i][j]=='A') {
					resul+=goA(i,j);
				}else if(map[i][j]=='B') {
					resul+=goB(i,j);
				}else if(map[i][j]=='C') {
					resul+=goC(i,j);
				}
			}
		}
		return resul;
	}
	
	static boolean inMap(int x,int y) {
		return x>=0&&x<N&&y>=0&&y<N;
	}
	
	private static int goC(int x,int y) {
		// TODO Auto-generated method stub
		int cnt=0;
		for (int i = 0; i < Cx.length; i++) {
			int nx=x+Cx[i];
			int ny=y+Cy[i];
			while(inMap(nx,ny)&&(map[nx][ny]=='S')) {
				cnt++;
				nx+=Cx[i];
				ny+=Cy[i];
			}
		}
		return cnt;
	}
	private static int goB(int x,int y) {
		// TODO Auto-generated method stub
		int cnt=0;
		for (int i = 0; i < Bx.length; i++) {
			int nx=x+Bx[i];
			int ny=y+By[i];
			while(inMap(nx,ny)&&(map[nx][ny]=='S')) {
				cnt++;
				nx+=Bx[i];
				ny+=By[i];
			}
		}
		return cnt;
	}
	private static int goA(int x,int y) {
		// TODO Auto-generated method stub
		int cnt=0;
		for (int i = 0; i < Ax.length; i++) {
			int nx=x+Ax[i];
			int ny=y+Ay[i];
			while(inMap(nx,ny)&&(map[nx][ny]=='S')) {
				cnt++;
				nx+=Ax[i];
				ny+=Ay[i];
			}
		}
		return cnt;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		T=sc.nextInt();
		for (int tc = 1; tc <=T; tc++) {
			N=sc.nextInt();
			map=new char[N+1][N+1];
			for (int i = 0; i <N; i++) {
				for (int j = 0; j <N; j++) {
					char input=sc.next().charAt(0);
					map[i][j]=input;
				}
			}
			System.out.println("#"+tc+" "+go());
		}//tc
	}

}
